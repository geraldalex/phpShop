<?php
class UserController{
    public function actionRegister(){
        $name ='';
        $email = '';
        $password ='';
        
        if(isset($_POST['submit'])){
            $name = $_POST['name'];
            $email = $_POST['email'];
            $password = $_POST['password'];
            
            $errors = false;
          
            if(User::checkName($name)){
          
                $errors[] = 'Имя должно быть не корче 2-х символов';
            }
            
           
            if(User::checkEmail($email)){
                
                $errors[] = 'Неправильный email';
            }
            
             
            if(User::checkName($password)){
               
                $errors[] = 'Пароль должно быть не корче 6-ти символов';
            }
            
            if(!User::checkEmailExists($email)){
                $errors[] = 'Такой email уже существует';
            }
            
            if($errors==false){
                
            }
             }
            
            
        
        
        
        
        
        require_once (ROOT.'/views/user/register.php');
        return true;
    }
}