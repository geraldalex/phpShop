<?php

// FRONT CONTROLLER

// Общие настройки
ini_set('display_errors',1);
error_reporting(E_ALL);

session_start();

// Подключение файлов системы
define('ROOT', dirname(__FILE__));
include ROOT.'/components/Autoload.php';
//include ROOT.'/components/Router.php';
//include ROOT.'/components/Db.php';



    




$router = new Router();
$router->run();